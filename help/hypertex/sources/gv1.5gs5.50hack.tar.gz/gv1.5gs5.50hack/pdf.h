/* This file is part of the hacked version of the ghostview package */
/* which is distributed under the terms of the gnu license. The */
/* modification referred to above is by Tanmoy Bhattacharya, */
/* <tanmoy@qcd.lanl.gov> on Nov 17, 1994. Neither the modification, */
/* nor the original program provides any warranty. */
#ifndef NeedFunctionPrototypes
#if defined(FUNCPROTO) || defined(__STDC__) || defined(__cplusplus) || defined(c_plusplus)
#define NeedFunctionPrototypes 1
#else
#define NeedFunctionPrototypes 0
#endif /* __STDC__ */
#endif /* NeedFunctionPrototypes */
#if NeedFunctionPrototypes

void pdf_process(char buf[]);
void pdf_clear(int pageno);
int pdf_page(int x, int y);
int dest_page(const char* name);

struct target_entry {
  char *file;
  char *name;
  int   page;
} *pdf_find(int x, int y);
#else
void pdf_process();
void pdf_clear();
int pdf_page();
int dest_page();

struct target_entry {
  char *file;
  char *name;
  int   page;
} *pdf_find();
#endif
