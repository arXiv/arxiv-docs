main()
{
	printf("a: \a...\n");
	printf("b: \b... ... ...\n");
	printf("e: \e... ... ...\n");
	printf("f: \f...\n");
	printf("n: \n...\n");
	printf("r: \r... ... ...\n");
	printf("t: \t...\n");
	printf("v: \v...\n");
}
